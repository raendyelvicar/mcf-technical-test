﻿
var app = new Vue({
    el: '#app',
    data: {
        username : null,
        password : null
    },
    methods: {
        login: function () {
            let self = this;
            // Specify the API endpoint for add new bpkb data
            let endpointUrl = 'https://localhost:7044/api/auth/login';

            // Form data to be sent in the request body
            const formData = {
                username: self.username,
                password: self.password
            }

            // Make a POST request using the Fetch API
            fetch(endpointUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            }).then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(res => {
                    sessionStorage.setItem("jwtToken", res.token)
                    location.href = "/Home/Index"
                })
                .catch(error => {
                    console.error('Error:', error);
                });
              
        },
    }
})