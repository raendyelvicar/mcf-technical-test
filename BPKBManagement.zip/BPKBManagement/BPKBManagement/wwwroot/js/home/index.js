﻿let baseApiUrl = 'https://localhost:7044/api';

var app = new Vue({
    el: '#app',
    data: {
        message: 'Hello Vue!',
        trBpkbList: []
    },
    methods: {
        getTrBpkbList: function () {
            let self = this;
            // Specify the API endpoint for bpkb data
            let endpointUrl = baseApiUrl + '/bpkbs';
            let token = sessionStorage.getItem('jwtToken');

            fetch(endpointUrl, {
                method: "GET",
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Authorization': `Bearer ${token}`
                }
            })
                .then((response) => {
                    response.json().then((res) => {
                        self.trBpkbList = res.data
                    });
                })
                .catch((err) => {
                    console.error(err);
                });
        },
    },
    mounted() {
        this.getTrBpkbList()
    }
})