﻿let baseApiUrl = 'https://localhost:7044/api';

var app = new Vue({
    el: '#app',
    data: {
        message: 'Hello Vue!',
        locations:[],
        agreementNumber : null,
        branchId : null,
        bpkbNo : null,
        bpkbDateIn : null,
        bpkbDate : null,
        fakturNo : null,
        fakturDate : null,
        policeNo : null,
        locationId : null
    },
    methods: {
        getLocationList: function () {
            let self = this;
            // Specify the API endpoint for bpkb data
            let endpointUrl = baseApiUrl + '/locations';

            fetch(endpointUrl, {
                method: "GET",
                headers: {
                    'Access-Control-Allow-Origin': '*'
                }
            })
                .then((response) => {
                    response.json().then((res) => {
                        self.locations = res.data
                    });
                })
                .catch((err) => {
                    console.error(err);
                });
        },
        addNewTrBpkb: function () {
            let self = this;
            // Specify the API endpoint for add new bpkb data
            let endpointUrl = baseApiUrl + '/bpkb';
            let token = sessionStorage.getItem('jwtToken');

            // Form data to be sent in the request body
            const formData = {
                agreementNumber: self.agreementNumber,
                bpkbNo: self.bpkbNo,
                branchId: self.branchId,
                bpkbDate: self.bpkbDate,
                fakturNo: self.fakturNo,
                fakturDate: self.fakturDate,
                locationId: self.locationId,
                policeNo: self.policeNo,
                bpkbDateIn: self.bpkbDateIn,
                createdBy: self.createdBy,
                createdOn: self.createdOn
            }
            
            // Make a POST request using the Fetch API
            fetch(endpointUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(formData),
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(res => {
                    location.href = "/"
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        },
        reformatDate: function (str) {
            var splitDate = str.split(/[\s/:-]+/);
            console.log(splitDate)
            return new Date(splitDate[0], splitDate[1], splitDate[2]);
        }
    },
    mounted() {
        this.getLocationList()
    }
})