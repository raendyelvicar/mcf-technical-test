﻿function isAuthenticated() {
    const jwtToken = sessionStorage.getItem('jwtToken');

    // Check if token exists and is not expired (you may need additional logic to check expiry)
    return jwtToken !== null;
}