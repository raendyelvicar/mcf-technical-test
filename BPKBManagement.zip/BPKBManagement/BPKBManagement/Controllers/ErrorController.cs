﻿using Microsoft.AspNetCore.Mvc;

namespace BPKBManagement.Controllers
{
    public class ErrorController : Controller
    {
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}
