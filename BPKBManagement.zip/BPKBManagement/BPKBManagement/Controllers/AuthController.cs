﻿using BPKBManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace BPKBManagement.Controllers
{
    public class AuthController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuthController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Login()
        {
            return View();
        }
            
        [HttpPost]
        public async Task OnSubmit([FromBody] LoginModel model)
        {

            using (HttpClient client = new HttpClient())
            {
                // URL of the API endpoint
                string url = "https://localhost:7044/api/auth/login";

                var loginModel = new {
                    username = model.Username,
                    password = model.Password,
                };
                // Serialize the data to JSON
                string json = JsonConvert.SerializeObject(loginModel);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                // Make the POST request
                HttpResponseMessage response = await client.PostAsync(url, content);

                // Ensure the request was successful
                response.EnsureSuccessStatusCode();

                // Read the response content
                string responseBody = await response.Content.ReadAsStringAsync();

                var jsonResponse = JsonConvert.DeserializeObject<LoginResponseModel>(responseBody);
                if(jsonResponse is not null)
                {
                    HttpContext.Session.SetString("jwtToken", jsonResponse.token);
                }
            }
            
        }
    }
}
