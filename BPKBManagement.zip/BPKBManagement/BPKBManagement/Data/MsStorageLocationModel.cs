﻿namespace BPKBManagement.Data
{
    public class MsStorageLocationModel
    {
    }
}
