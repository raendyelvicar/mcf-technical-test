﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BPKBManagement
{
    public class BPKBController : Controller
    {
        // GET: BPKBController
        public ActionResult Index()
        {
            return View();
        }

        // GET: BPKBController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: BPKBController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: BPKBController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BPKBController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: BPKBController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BPKBController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: BPKBController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
