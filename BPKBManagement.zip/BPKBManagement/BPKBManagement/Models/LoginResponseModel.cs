﻿namespace BPKBManagement.Models
{
    public class LoginResponseModel
    {
        public string token {  get; set; } 
        public string expiration {  get; set; }
    }
}
